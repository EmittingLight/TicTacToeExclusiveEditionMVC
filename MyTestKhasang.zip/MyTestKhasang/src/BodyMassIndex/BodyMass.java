package BodyMassIndex;

public class BodyMass {
    public static void main(String[] args) {
        double index = massIndex(70.5, 1.68);
        System.out.println("Индекс вашего тела: " + index);
    }
    private static double massIndex(double weight, double height) {
        return weight / (height * height);
    }
}
