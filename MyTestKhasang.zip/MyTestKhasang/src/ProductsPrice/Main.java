package ProductsPrice;

public class Main {
    public static void main(String[] args) {
        showProducts(new String[]{"Вермишель", "Куркума", "Пицца"}, 100, 40);
    }

    public static void showProducts(String[] names, int... prices) {
        int count = 0;
        System.out.println("Продукты в наличии:");
        for (int i = 0; i < prices.length; i++) {
                System.out.println(names[count] + " " + prices[i] + " руб.");
                count++;
        }

        for (int i = count; i < names.length; i++) {
            System.out.println(names[i]);

        }
    }
}



