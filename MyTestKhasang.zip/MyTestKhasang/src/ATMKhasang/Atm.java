package ATMKhasang;

public class Atm {
    public static void main(String[] args) {
        withdraw(42, 3);
        withdraw(100, 110);
    }

    static void withdraw(int allMoney, int needMoney) {
        System.out.println("У вас было " + allMoney + " руб.");
        System.out.println("Вы захотели снять " + needMoney + " руб.");
        int moneyleft = allMoney - needMoney; // сколько денег бы осталось
        if (allMoney < needMoney) {
            System.out.println("Отрицательный баланс запрещен, увы");
            return;
        }
        System.out.println("У вас осталось " + moneyleft + " руб.");
    }
}
