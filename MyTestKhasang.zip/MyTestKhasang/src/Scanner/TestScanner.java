package Scanner;

import java.util.Scanner;

public class TestScanner {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число");
        int i = scanner.nextInt();
        scanner.nextLine();
        System.out.println(i);
        System.out.println("Введите строку");
        String string = scanner.nextLine();
        System.out.println(string);
    }
}
