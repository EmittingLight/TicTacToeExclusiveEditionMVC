package Return;

public class Main {
    public static void main(String[] args) {
        int s;
        s = difference(42, 3);
        System.out.println(s);
    }

    static int difference(double a, double b) {
        double c = a - b;
        return (int) c;
    }
}


