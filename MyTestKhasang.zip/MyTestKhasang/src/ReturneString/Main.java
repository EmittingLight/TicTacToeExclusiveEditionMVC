package ReturneString;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        match("a@mail.io"); // true
        match("a@ma-il.ru"); // true
        match("dude@coolmail.com"); // true
        match("dude@cool-mail.net"); // true
        match("dude_aaa@gmail.io"); // true
        match("dude_aaa222@somemail.site"); // true
        match("dude111@yandex.dev"); // true
        match("2342@yahoo.com"); // true

        match("a@mail.a"); // false
        match("a@mail."); // false
        match("a@ma-il."); // false
        match("dude@coolmail."); // false
        match("dude@cool-mail."); // false
        match("dude_aaa@gmail."); // false
        match("dude_aaa222@somemail."); // false
        match("dude111@yandex."); // false
        match("2342@yahoo."); // false
    }

    static void match(String email) {
        String pattern = "[a-z_0-9]+@[a-z\\-]+\\.[a-z]{2,}";
        System.out.println(email.matches(pattern));
    }
}