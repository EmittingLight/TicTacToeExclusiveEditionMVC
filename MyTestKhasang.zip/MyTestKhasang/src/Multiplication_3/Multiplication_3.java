package Multiplication_3;

public class Multiplication_3 {
    public static void main(String[] args) {
        multiplication(2, 10);
        multiplication(6, 9);
    }

    private static void multiplication(int from, int to) {
        for (int i = 1; i <= 10; i++) {
            for (int j = from; j <= to; j++) {
                System.out.print(j + " x " + i + " = " + (i * j) + "\t");
            }
            for (int k = i; k < 10; k++) {
                System.out.print("\t");


            }
        }
        System.out.println();
    }
}


