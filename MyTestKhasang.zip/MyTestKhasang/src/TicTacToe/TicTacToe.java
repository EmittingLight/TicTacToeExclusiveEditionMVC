package TicTacToe;

import java.util.Random;
import java.util.Scanner;

public class TicTacToe {
    static char symbol_x = 'X';
    static char symbol_o = 'O';
    static char symbolEmpty = '.';
    static char[][] cells;
    static Random random;
    static Scanner scanner;

    public static void main(String[] args) {
        new TicTacToe();
        game();
    }

    public TicTacToe() {
        cells = new char[3][3];
        random = new Random();
        scanner = new Scanner(System.in);
    }


    static void game() {
        drawTable();
        while (true) {
            playerOne();
            if (checkWin(symbol_x)) {
                System.out.println("Игрок 1 Победил!");
                break;
            }
            if (isTableFull()) {
                System.out.println("Ничья!");
                break;
            }
            playerTwo();
            showTable();
            if (checkWin(symbol_o)) {
                System.out.println("Ничья!");
                break;
            }
            if (isTableFull()) {
                System.out.println("Эта ячейка занята!");
                break;
            }
        }
        System.out.println("Конец игры");
        showTable();
    }


    static void drawTable() {
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                cells[row][column] = symbolEmpty;
            }
        }
    }

    static void showTable() {
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                System.out.print(cells[row][column] + " ");
            }
            System.out.println();
        }
    }

    static void playerOne() {
        int x;
        int y;
        do {
            System.out.println("Игрок 1 введите координаты x и y:");
            x = scanner.nextInt() - 1;
            y = scanner.nextInt() - 1;
        } while (!isNothing(x, y));
        cells[x][y] = symbol_x;
        showTable();
    }

    static void playerTwo() {
        int x;
        int y;
        do {
            System.out.println("Игрок 2 введите координаты x и y: ");
            x = scanner.nextInt() - 1;
            y = scanner.nextInt() - 1;
        } while (!isNothing(x, y));
        cells[x][y] = symbol_o;
    }

    static boolean isNothing(int x, int y) {
        if (x < 0 || y < 0 || x >= 3 || y >= 3) {
            return false;
        }
        return cells[y][x] == symbolEmpty;
    }

    static boolean checkWin(char dot) {
        for (int i = 0; i < 3; i++) {
            if ((cells[i][0] == dot && cells[i][1] == dot && cells[i][2] == dot) ||
                    (cells[0][i] == dot && cells[1][i] == dot && cells[2][i] == dot)) {
                return true;
            }
            if ((cells[0][0] == dot && cells[1][1] == dot && cells[2][2] == dot) ||
                    (cells[2][0] == dot && cells[1][1] == dot && cells[0][2] == dot)) {
                return true;
            }
        }
        return false;
    }

    static boolean isTableFull() {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if (cells[row][col] == symbolEmpty) {
                    return false;
                }
            }
        }
        return true;
    }
}
