package Multiplication_2;

public class Multiplication_2 {
    public static void main(String[] args) {
        multiplication(2, 5);
        multiplication(6, 9);
    }

    private static void multiplication(int from, int to) {
        for (int i = 1; i <= 10; i++) {
            for (int j = from; j <= to; j++) {
                System.out.print(j + " x " + i + " = " + (i * j) + "\t");
            }
            System.out.println();
        }
        System.out.println();
    }
}
