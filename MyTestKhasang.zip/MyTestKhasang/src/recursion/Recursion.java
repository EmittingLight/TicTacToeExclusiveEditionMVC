package recursion;

public class Recursion {
    public static void main(String[] args) {
        go(1);
    }

    static void go(int i) {
        if (i >= 50) {
            return;
        }
        System.out.println(i);
        go(i * 2);
    }
}
