package SortMass;

public class RecursiveArraySplitting {
    public static void main(String[] args) {
        int[] array = {2, 1, 7, 2, 5};
        System.out.println(partition(array, 0, 1));
        sort(array, 0, 1);
    }

    public static int partition(int[] array, int from, int to) {
        return 1;
    }

    public static void sort(int[] array, int from, int to) {
        if (array.length == 0) {
            return;
        }
        System.out.println(from + " " + to);
        int pivot = partition(array, from, to);
        sort(array, from, pivot - 1);
        sort(array, pivot + 1, to);
    }
}

