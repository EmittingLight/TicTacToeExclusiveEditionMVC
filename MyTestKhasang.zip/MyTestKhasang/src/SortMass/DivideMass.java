package SortMass;

public class DivideMass {
    public static void main(String[] args) {
        int[] array = {3, 9, 1, 3, 1, 5, 4, 2, 4};
        for (int i = 0; i < array.length - 1; i++) {
            int max = 2;
            if (array[i] > 0) {

            }
        }
        //divide(array, 0, array.length - 1);
        //divide(array, 2, 3);
    }

    public static void divide(int[] array, int first, int last) {
        int mid = (first + last) / 2;
        for (int i = 0; i < array.length - 1; i++) {
            System.out.println(array[i + 1]);
        }
        //System.out.println(array[mid] + " " + last);
    }
}
