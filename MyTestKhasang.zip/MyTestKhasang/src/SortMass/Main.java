package SortMass;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] array = {2, 1};
        System.out.println(Arrays.toString(sort(array)));
    }

    public static int[] sort(int[] arrays) {
        return arrays;
    }
}

