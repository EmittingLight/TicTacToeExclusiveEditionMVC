package SortMass;

public class QuickSort {
    public static void main(String[] args) {
        int[] array = {3, 1, 7, 4, 5, 9, 20};
        System.out.println(partition(array, 0, 1));
    }

    static int partition(int[] array, int left, int right) {
        int middle = left + (right - left) / 2;
        int partition = array[middle];
        int i = left;
        int j = right;
        while (i <= j) {
            while (array[i] < partition) {
                i++;
            }

            while (array[j] > partition) {
                j--;
            }
            if (i <= j) {
                int temp = array[i];
                array[i] = array[j];
                array[j] = temp;
                i++;
                j--;
            }
            if (left < j)
                partition(array, left, j);

            if (right > i)
                partition(array, i, right);
        }
        return middle;
    }
}
