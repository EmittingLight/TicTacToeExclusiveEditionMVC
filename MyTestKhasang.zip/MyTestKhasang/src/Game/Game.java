package Game;

import java.util.Scanner;

public class Game {
    public static void main(String[] args) {
        showRules();
        int sum = game();
        showResult(sum);
    }

    static void showRules() {
        System.out.println("Наберите сумму чисел равную 21");
    }

    static void showResult(int sum) {
        if (sum == 21) {
            System.out.println("Сумма набрана!");
        } else {
            System.out.println("Попробуйте выиграть в следующий раз");
        }
    }

    static int game() {
        int sum = 0;
        Scanner scanner = new Scanner(System.in);

        while (true) {
            String strMenu = scanner.nextLine();
            int intMenu = Integer.parseInt(strMenu);
            if (intMenu == 0) {
                System.out.println("Введите любое число для продолжения или число 0 для выхода " );
                //return sum;
            }
            int randomNumber;
            randomNumber = 5;
            sum += randomNumber;
            System.out.println("Число " + randomNumber);
            System.out.println("Сумма равна " + sum);
            if (sum >= 21) {
                break;
            }
        }
        return sum;
    }
}