package Test4Receipt;

public class TestReceipt {
    public static void main(String[] args) {
        String plate;
        plate = "Лист салата, ";
        plate = plate + "Соль, ";
        plate = plate + "Укроп, ";
        plate = plate + blender("помидорки, ");
        System.out.println(plate);
    }

    private static String blender(String vegetable) {
        return "нарезанные " + vegetable;
    }
}
