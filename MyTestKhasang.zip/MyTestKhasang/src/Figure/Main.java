package Figure;

public class Main {
    public static void main(String[] args) {
        int[] dailyCases = {100, 150, 170, 190, 210, 230};
        show(dailyCases);
    }

    static void show(int[] dailyCases) {
        char c = '-';
        for (int i = 0; i < dailyCases.length; i++) {
            if (dailyCases[i] > dailyCases.length - 1) {
                dailyCases[i] = c;
                System.out.print(dailyCases[i]);
            }
        }
    }
}

