package TimeDifinition;

public class Timing {
    public static void main(String[] args) {
        System.out.println(goodDay(6));
        System.out.println(goodDay(17));
        System.out.println(goodDay(22));
        System.out.println(goodDay(2));
    }

    public static String goodDay(int hours) {
        if (hours > 24 || hours < 0) {
            return "Неверные входные данные";
        }
        if (hours >= 4 && hours < 10) {
            return "Доброго утра";
        }
        if (hours >= 10 && hours < 19) {
            return "Доброго дня";
        }
        if (hours >= 19 && hours < 23) {
            return "Добрый вечер";
        } else {
            return "Доброй ночи";
        }
    }
}


// 1. Для невалидных данных (меньше нуля или больше 24) возвращает "Неверные входные данные";
// if (hour > 24 || hour < 0) {
//     return "Неверные входные данные";
// }
// 2. Возвращает "Добрый вечер", если время в диапазоне от 19 (включая) до 23 часов (не включая).
// 3. Возвращает "Доброй ночи", если время в диапазоне от 23 (включая) до 4 часов (не включая).
// 4. Возвращает "Доброго утра", если время в диапазоне от 4 (включая) до 10 часов (не включая).
// 5. Возвращает "Доброго дня", если время в диапазоне от 10 (включая) до 19 часов (не включая).


