package TryCatch;

public class TryCatch {
    public static void main(String[] args) {
        for (int i = 0; i < 500000000; i++) {
            System.out.println(i);
            pause(1000);
        }
    }

    private static void pause(int delay) {
        try {
            Thread.sleep(delay);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
