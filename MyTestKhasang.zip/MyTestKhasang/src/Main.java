public class Main {
    public static void main(String[] args) {
        showProducts(new String[]{"Вермишель", "Куркума", "Пицца"}, "Манка", "Гречка", "Рис");
    }

    static void showProducts(String[] productsInStock, String... productsOutOfStock) {
        System.out.println("Продукты в наличии:");
        for (int i = 0; i < productsInStock.length; i++) {
            System.out.println(productsInStock[i]);
        }
        System.out.println();
        System.out.println("Продуктов нет в наличии:");
        for (int i = 0; i < productsOutOfStock.length; i++) {
            System.out.println(productsOutOfStock[i]);

        }
    }
}

