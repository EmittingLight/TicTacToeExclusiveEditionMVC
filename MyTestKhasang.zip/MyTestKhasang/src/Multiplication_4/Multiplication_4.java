package Multiplication_4;

public class Multiplication_4 {
    public static void main(String[] args) {
        multiplication(2, 5);
    }

    private static void multiplication(int from, int to) {
        for (int i = 1; i <= 10; i++) {
            for (int j = from; j <= to; j++) {
                System.out.print(j + " x " + i + " = " + (i * j) + "\t");
            }
            System.out.println();
        }
        System.out.println();
        //for (int i = from; i < to; i++) {
           // multiplication(i, i);

        //}
    }
}


