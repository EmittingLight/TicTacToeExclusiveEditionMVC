package TicTacToeLimitedEdition_2;

public class Main {
    public static void main(String[] args) {
        TicTacToeLimitedEdition_2 ticTacToeLimitedEdition_2 = new TicTacToeLimitedEdition_2();
    }
}
