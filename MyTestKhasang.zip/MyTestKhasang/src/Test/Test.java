package Test;

public class Test {
    public static void main(String[] args) {
        System.out.println(amPm(11));
        System.out.println(amPm(2));
        System.out.println(amPm(19));
        System.out.println(convert24To12(18));
        System.out.println(convert24To12(10));
        System.out.println(convert24To12(11));
    }

    static String amPm(int hour) {
        String type = "";

        if (hour > 24 || hour < 0) {
            type = "Неверные входные данные";
        }
        if (hour >= 0 && hour < 12) {
            type = "am";
        }
        if (hour == 24) {
            type = "am";
        }
        if (hour >= 13 && hour <= 23) {
            type = "pm";
        }
        if (hour == 12) {
            type = "pm";
        }
        return type;
    }



    static int convert24To12(int hour) {
        int newHour = hour % 12;
        return newHour;
    }
}