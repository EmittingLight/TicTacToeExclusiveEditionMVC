package TaskChess;

import java.math.BigInteger;

public class Main {
    public static void main(String[] args) {
        go(1, BigInteger.valueOf(1));
    }

    static void go(int i, BigInteger count) {
        if (i == 65) {
            return;
        }
        System.out.println(i + " " + count);
        go(i + 1, count.multiply(BigInteger.valueOf(2)));
    }
}

